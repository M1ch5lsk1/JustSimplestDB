from justsimplestdb.owntypes import *
from justsimplestdb.JustSimplestDB import *